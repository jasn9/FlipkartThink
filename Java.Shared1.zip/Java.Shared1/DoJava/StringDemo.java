/*
javac StringDemo.java -d ClassFiles
java -cp ClassFiles/ learnJava.StringDemo
*/

package learnJava;

import java.time.ZoneId;
import java.util.Arrays;
import java.util.Scanner;

public class StringDemo {

	public static void stringDemo() {
		String location = "Java";
		String greeting = "Hello " + location;
		greeting = greeting + " World!";
		
		System.out.println(greeting);
		
		int age = 42;

		//BAD PRACTICE
		String output =  10 + age + " years"; //Implicitly Invoking toString for int type
		
		System.out.println(output);
		System.out.println(age); //Implicitly Invoking toString for int type
	
		System.out.println("Ding Dong " + age + 1);
		System.out.println("Ding Dong " + (age + 1) );
	
		String names = String.join(" : ", "Ding", "Dong", "Ping", "Pong");
		System.out.println(names);

		//import java.time.ZoneId;

		//Indexing For Loop
		//for (int i = 0 ; i <= 100, i++ ) {  }

		//System.out.println(ZoneId.getAvailableZoneIds());
		
		StringBuilder builder = new StringBuilder();

		//BEST PRACTICE - Prefer Enhanced For Loop Rather Than Indexing Loop
		for (String id: ZoneId.getAvailableZoneIds() ) {
			builder.append(id);
			builder.append(", ");
		}

		String result = builder.toString();
		System.out.println(result);
		System.out.println(result.length());
		System.out.println(result.substring(0, 200) + "...");
	
		greeting = "Hello, World!";
		location = greeting.substring(7, 12);
		System.out.println(location);

		String greeting1 = "Hello, World!";
		String greeting2 = "Hello, World!";

		System.out.println(location.equals("World"));
		System.out.println(location == "World");

		System.out.println(greeting1 == greeting2);
		System.out.println(greeting1 == greeting);
		System.out.println(greeting2 == greeting);

        // Converting between numbers and strings
        int n = 42;
        String str = Integer.toString(n, 2);
        System.out.println(str);
        
        n = Integer.parseInt(str);
        System.out.println(n);
        
        n = Integer.parseInt(str, 2);
        System.out.println(n);

        double x = Double.parseDouble("3.14"); 
        System.out.println(x);
        
        System.out.println(greeting.toUpperCase());
        System.out.println(greeting); // greeting is not changed

        // Unicode
        String javatm = "Java\u2122";
        System.out.println(javatm);
        System.out.println(Arrays.toString(javatm.codePoints().toArray()));
        System.out.println(javatm.length());
        
        String octonions = "\ud835\udd46";
        System.out.println(octonions);
        System.out.println(Arrays.toString(octonions.codePoints().toArray()));
        System.out.println(octonions.length()); // Counts code units, not Unicode code points

	}

	public static void inputDemo() {
        Scanner in = new Scanner(System.in);
        System.out.println("What is your name?");
        String name = in.nextLine();
        System.out.println("How old are you?");
        if (in.hasNextInt()) {
            int age = in.nextInt();
            System.out.printf("Hello, %s. Next year, you'll be %d.\n", name, age + 1);
        } else {
            System.out.printf("Hello, %s. Are you too young to enter an integer?", name);
        }
    }

    public static void whileDemo() {
		  Random generator = new Random();
	      int sum = 0;
	      int count = 0;
	      int target = 90;
	      while (sum < target) {
	         int next = generator.nextInt(10);
	         sum = sum + next;
	         count++;
	      }
	      System.out.println("After " + count 
	         + " iterations, the sum is " + sum);
	 }

	public static void main(String[] args) {
		System.out.println("Hello World!");
		
		stringDemo();
		inputDemo();
		whileDemo();
	}
}
