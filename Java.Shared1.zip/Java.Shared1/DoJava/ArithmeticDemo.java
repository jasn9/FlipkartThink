/*
javac ArithmeticDemo.java -d ClassFiles
java -cp ClassFiles/ learnJava.ArithmeticDemo
*/

package learnJava;

import java.math.BigDecimal;
import java.math.BigInteger;

public class ArithmeticDemo {
    public static void arithmeticDemo() {
        // Division and remainder
        
        System.out.println(17 / 5);
        System.out.println(17 % 5);
        System.out.println(Math.floorMod(17, 5));
        
        System.out.println(-17 / 5);
        System.out.println(-17 % 5);
        System.out.println(Math.floorMod(-17, 5));
        
        // Increment and decrement
        
        int[] a = { 17, 29 };
        int n = 0;
        System.out.printf("%d %d\n", a[n++], n); 
        n = 0;
        System.out.printf("%d %d\n", a[++n], n);
        
        // Powers and roots
        
        System.out.println(Math.pow(10, 9));
        System.out.println(Math.sqrt(1000000));
        
        // Number conversions
        
        double x = 42;
        System.out.println(x); // 42.0
        
        float f = 123456789;
        System.out.println(f); // 1.23456792E8
        
        x = 3.75;
        n = (int) x;
        System.out.println(n); // 3
        
        n = (int) Math.round(x); 
        System.out.println(n); // 4
        
        System.out.println('J' + 1); // 75
        char next = (char)('J' + 1); 
        System.out.println(next); // 'K'
        
        n = (int) 3000000000L; 
        System.out.println(n); // -1294967296
    }
    
    public static void relationalDemo() {
        int length = 10;
        int n = 7;
        System.out.println(0 <= n && n < length);
        
        // Short circuit evaluation
        int s = 30;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        n = 0;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        System.out.println(n == 0 || s + (1 - s) / n >= 50);
        
        int time = 7;
        System.out.println(time < 12 ? "am" : "pm");
    }

    public static void bigNumbersDemo() {
        BigInteger n = BigInteger.valueOf(876543210123456789L);
        BigInteger k = new BigInteger("9876543210123456789");
        
        // r = 5 * (n + k)
        BigInteger r = BigInteger.valueOf(5).multiply(n.add(k)); 
        
        System.out.println(r);
        System.out.println(2.0 - 1.1);
        
        BigDecimal d = BigDecimal.valueOf(2, 0).subtract(
            BigDecimal.valueOf(11, 1));
        
        System.out.println(d);
    }

    public static void main(String[] args) {
        arithmeticDemo();    
        relationalDemo();
        bigNumbersDemo();
    }

}
