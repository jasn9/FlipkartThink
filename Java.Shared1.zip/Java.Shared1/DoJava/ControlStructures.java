/*
javac ControlStructures.java -d ClassFiles
java -cp ClassFiles/ learnJava.ControlStructures
*/
//ControlStructures.Java

package learnJava;

import java.util.Random;

public class ControlStructures {
	public static void whileDemo() {
		  Random generator = new Random();
	      int sum = 0;
	      int count = 0;
	      int target = 90;
	      while (sum < target) {
	         int next = generator.nextInt(10);
	         sum = sum + next;
	         count++;
	      }
	      System.out.println("After " + count 
	         + " iterations, the sum is " + sum);
	 }

   public static void doWhile() {
      Random generator = new Random();      
      int target = 5;
      int count = 1;
      int next;
      do {
         next = generator.nextInt(10);
         count++;
      } while (next != target);
         
      System.out.println("After " + count + " iterations, there was a values of " + target);
   }

   public static void forLoop() {
      Random generator = new Random();      
      int count = 20;
      int sum = 0;
      for (int i = 1; i <= count; i++ ) {
         int next = generator.nextInt(10);
         sum = sum + next;         
      }
      System.out.println("After " + count 
         + " iterations, the sum is " + sum);
   }

	public static void main(String[] args) {
		System.out.println("Hello World!");

		whileDemo();
		doWhile();
		forLoop();
	}
}

