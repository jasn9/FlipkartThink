import string
import sys

words = { }
for file in sys.argv[1:]:
	for line in open(file):
		for word in line.lower().split():
			word = word.strip()
			if len(word) > 2:
					words[word] = words.get(word, 0) + 1

print(words)












import string
import sys

words = { }
strip = string.whitespace + string.punctuation + string.digits + "\"'"

for file in sys.argv[1:]:
	for line in open(file):
		for word in line.lower().split():
			word = word.strip(strip)
			if len(word) > 2:
					words[word] = words.get(word, 0) + 1
print(words)






import string
import sys

words = { }
strip = string.whitespace + string.punctuation + string.digits + "\"'"

for file in sys.argv[1:]:
#	filein = fopen()
	for line in filedata.chunk(size):
#		filedata = filein.fread( size...)
#		Logic for identifying line and splitting that
		for word in line.lower().split():
			word = word.strip(strip)
			if len(word) > 2:
					words[word] = words.get(word, 0) + 1

#		size = size + chunk
print(words)


#How a particular objects works internally...
#filecontent = fin.fread(

#for word in sorted(words):
#		print("{0} word frequence is: {1}".format(word, words[word]))
