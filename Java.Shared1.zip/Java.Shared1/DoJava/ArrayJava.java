/*
javac ArrayJava.java -d ClassFiles
java -cp ClassFiles/ learnJava.ArrayJava
*/

package learnJava;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class ArrayJava {

	public static void arrayDemo() {
        
        String[] names = new String[10];
        for (int i = 0; i < names.length / 2; i++) {
            names[i] = "";
        }

        names[0] = "Fred";
        names[1] = names[0];
        System.out.println("names="+Arrays.toString(names));
        

        int[] primes1 = { 17, 19, 23, 29, 31 };
        // Enhanced for loop
        int sum = 0;
        for (int n : primes1) {
            sum += n;
        }
        System.out.println("sum=" +sum);
        
    	int[] primes = new int[] { 2, 3, 5, 7, 11, 13 };
//    	Integer[] primes = new Integer[] { 2, 3, 5, 7, 11, 13 };
        int[] numbers = primes;
        numbers[5] = 42; 
        System.out.println("primes=" + Arrays.toString(primes));
// primes=[2, 3, 5, 7, 11, 42]
        
        primes[5] = 13;
        int[] copiedPrimes = Arrays.copyOf(primes, primes.length);
        copiedPrimes[5] = 31; 
        System.out.println("primes=" + Arrays.toString(primes));
        System.out.println("copiedPrimes=" + Arrays.toString(copiedPrimes));
    
// primes=[2, 3, 5, 7, 11, 13]
// copiedPrimes=[2, 3, 5, 7, 11, 31]

    }

    public static void arrayListDemo() {
        ArrayList<String> friends = new ArrayList<>();
        friends.add("Peter");
        friends.add("Paul");
        friends.remove(1);
        friends.add(0, "Paul"); // Adds before index 0

        System.out.println("friends=" + friends);

        String first = friends.get(0);
        System.out.println("first=" + first);
        friends.set(1, "Mary");

        for (int i = 0; i < friends.size(); i++) {
            System.out.println(friends.get(i));
        }

        ArrayList<String> people = friends;
        people.set(0, "Mary"); 
        System.out.println("friends=" + friends);
        
        ArrayList<String> copiedFriends = new ArrayList<>(friends);
        copiedFriends.set(0, "Fred"); 
        System.out.println("copiedFriends=" + copiedFriends);
        System.out.println("friends=" + friends);

//        ArrayList<int> something = new ArrayList<>();
        // ArrayList<Integer> something = new ArrayList<Integer>();
        ArrayList<Integer> something = new ArrayList<>();
		something.add(10);
		something.add(20);
		something.add(30);
		something.add(40);
		something.add(50);
		//something.add("DING");
		//something.add(90.9);

		for (Integer item: something) {
			System.out.println(item);
		}
        
        friends = new ArrayList<>(Arrays.asList("Peter", "Paul", "Mary"));
        String[] names = friends.toArray(new String[0]);
        
        //String[] names = friends.toArray();
        //ArrayJava.java:96: error: incompatible types: Object[] cannot be converted to String[]
        //String[] names = friends.toArray();
        

        System.out.println("names=" + Arrays.toString(names));               
        
        ArrayList<String> moreFriends = new ArrayList<>(Arrays.asList(names));
        moreFriends.add("Ding Dong");
        System.out.println("moreFriends=" + moreFriends);         
        
        Collections.reverse(friends);
        System.out.println("After reversing, friends=" + friends);
        Collections.shuffle(friends);
        System.out.println("After shuffling, friends=" + friends);
        Collections.sort(friends);        
        System.out.println("After sorting, friends=" + friends);
    }

	public static void swap(int[] values, int i, int j) {
        int temp = values[i];
        values[i] = values[j];
        values[j] = temp;
    }
    
    public static int[] firstLast(int[] values) {
        if (values.length == 0) return new int[0];
        else return new int[] { values[0], values[values.length - 1] };
    }
    
    public static void arrayMethodDemo() {
        int[] fibs = { 1, 1, 2, 3, 5, 8, 11, 13 };
        swap(fibs, 2, fibs.length - 2);
        System.out.println(Arrays.toString(fibs));
        System.out.println(Arrays.toString(firstLast(fibs)));        
    }

    public static double average(String something, double... values) {
        double sum = 0;
        System.out.println(values);
        for (double v : values) sum += v;
        return values.length == 0 ? 0 : sum / values.length;
    }    
    
    public static double max(double first, double... rest) {
        double result = first;
        System.out.println(rest);
        for (double v : rest) result = Math.max(v, result);
        return result;
    }
    
    public static void varArgsDemo() {
        int n = 42;
        System.out.printf("%d\n", n);
        System.out.printf("%d %s\n", n, "widgets");
        
        double[] scores = { 3, 4.5, 10, 0 };
        double avg = average("Ding Dong", scores);
        System.out.println(avg);
        
        double largest = max(3, 4.5, 10, 0);
        System.out.println(largest);
        
        // avg = average("Ding Dong", 3, 4.5, 10, 0, 100, 90, 80, 70 );
        // System.out.println(avg);
    }

	public static void main(String[] args) {
		System.out.println("Hello World!");

		arrayDemo();
		arrayListDemo();
		arrayMethodDemo();
		varArgsDemo();
	}
}
