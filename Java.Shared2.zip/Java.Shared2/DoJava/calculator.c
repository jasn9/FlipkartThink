#include <stdio.h>

int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }

int calculator(int x, int y, int (*operation)(int, int)) {
	return operation(x, y);
}

int main() {
	int a = 20, b = 30;
	int result = 0;

	result = calculator(a, b, sum);
	printf("\nResult: %d", result);
	
	result = calculator(a, b, sub);
	printf("\nResult: %d", result);

	return 0;
}
