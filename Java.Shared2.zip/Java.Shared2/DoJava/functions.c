#include <stdio.h>

int sum(int x, int y) { return x + y ;}
int sum(int x, int y, int z) { return x + y + z ;}

int main() {
	int result = 0;
	result = sum(10, 20);
	result = sum(20, 30, 40);
}

