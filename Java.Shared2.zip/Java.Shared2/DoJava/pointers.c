#include <stdio.h>

int sum(int x, int y) { return x + y; }
int sum3(int x, int y, int z) { return x + y + z; }

Employee emplopyee = new Employee("Ram", 800000);

Employee *employee = (Employee *) malloc(sizeof(Employee));
employee->name = "Ram";
emplyee->salary = 800000;
return employee;


int main() {
	char amessage[10] = "Ding Dong";
	char *pmessage = "Ding Dong";
	char *something = "Ping Pong";

	int (*fptr)(int, int) = sum;
	fptr  = sum3;


	pmessage = something;
//	amessage = something;

	printf("\nValues: %s %s", amessage, pmessage);
	printf("\nSum: %d", fptr(10, 20));
}
