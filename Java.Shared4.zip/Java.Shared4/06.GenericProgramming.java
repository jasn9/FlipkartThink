
//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec01;

public class Entry<K, V> {
    private K key;
    private V value;
    
    public Entry(K key, V value) {
        this.key = key;
        this.value = value;
    }
    
    public K getKey() { return key; }
    public V getValue() { return value; }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec02;

public class ArrayUtil {
    public static <T> void swap(T[] array, int i, int j) {
        T temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public static <T> T[] swap(int i, int j, T... values) {
        T temp = values[i];
        values[i] = values[j];
        values[j] = temp;
        return values;
    }
}
//_______________________________________________________________________________________

package ch06.sec02;

public class ArrayUtilDemo {
    public static void main(String[] args) {
        String[] friends = { "Peter", "Paul", "Mary" };
        ArrayUtil.swap(friends, 0, 1);
        
        // Uncomment to see error message
        // Double[] result = Arrays.swap(0, 1, 1.5, 2, 3);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec03;

import java.util.ArrayList;

public class Closeables {
    public static <T extends AutoCloseable> void closeAll(ArrayList<T> elems) throws Exception {
        for (T elem : elems) elem.close();
    }
}
//_______________________________________________________________________________________

package ch06.sec03;

import java.io.PrintStream;
import java.util.ArrayList;

public class CloseablesDemo {
    public static void main(String[] args) throws Exception {
        PrintStream p1 = new PrintStream("/tmp/1");
        PrintStream p2 = new PrintStream("/tmp/2");
        ArrayList<PrintStream> ps = new ArrayList<>();
        ps.add(p1);
        ps.add(p2);
        Closeables.closeAll(ps);        
    }
}
//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec04;

public class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public final String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

//_______________________________________________________________________________________

package ch06.sec04;

public class Manager extends Employee {
    private double bonus;
    
    public Manager(String name, double salary) {
        super(name, salary);
        bonus = 0;
    }
    
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    public double getSalary() { // Overrides superclass method
        return super.getSalary() + bonus;
    }
} 
//_______________________________________________________________________________________

package ch06.sec04;

import java.util.function.Predicate;

public class ArrayUtil {
    public static <T> void printAll(T[] elements, Predicate<? super T> filter) {
        for (T e : elements) 
            if (filter.test(e))
                System.out.println(e.toString());
    }
}

//_______________________________________________________________________________________

package ch06.sec04;

import java.util.ArrayList;
import java.util.function.Predicate;

public class Employees {
    public static void printNames(ArrayList<? extends Employee> staff) {
        for (int i = 0; i < staff.size(); i++) {
            Employee e = staff.get(i);
            System.out.println(e.getName());
        }
    }
    
    public static void printAll1(Employee[] staff, Predicate<Employee> filter) {
        for (Employee e : staff) 
            if (filter.test(e))
                System.out.println(e.getName());
    }

    public static void printAll2(Employee[] staff, Predicate<? super Employee> filter) {
        for (Employee e : staff) 
            if (filter.test(e))
                System.out.println(e.getName());
    }
    
    public static void main(String[] args) {
        Employee[] employees = {
          new Employee("Fred", 50000),
          new Employee("Wilma", 60000),
        };
        printAll1(employees, e -> e.getSalary() > 100000);
        printAll2(employees, e -> e.getSalary() > 100000);
        Predicate<Object> evenLength = e -> e.toString().length() % 2 == 0; 
        // printAll1(employees, evenLength);
        printAll2(employees, evenLength);
    }
}

//_______________________________________________________________________________________

package ch06.sec04;

import java.util.List;

public class Lists {
    public static boolean hasNulls(List<?> elements) {
        for (Object e : elements) {
            if (e == null) return true;
        }
        return false;
    }

    public static void swap(List<?> elements, int i, int j) {
        swapHelper(elements, i, j);
    }
    
    private static <T> void swapHelper(List<T> elements, int i, int j) {
        T temp = elements.get(i);
        elements.set(i, elements.get(j));
        elements.set(j, temp);
    }
}
//_______________________________________________________________________________________

package ch06.sec04;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HeapPollutionDemo {
    public static void demo(List<String> words) {
        List<?> elements = words;
        System.out.println("Cast to List<Integer>");
        @SuppressWarnings("unchecked")
        List<Integer> numbers = (List<Integer>) elements;
        System.out.println("Success");
        System.out.println("Inserting an integer");
        numbers.add(42);
        System.out.println("Success");
        System.out.println("Removing it as a string");
        String word = words.get(0);
        System.out.println("Success");
        System.out.println(word);
    }

    public static void main(String[] args) {
        try {
            demo(new ArrayList<>());
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
        try {
            demo(Collections.checkedList(new ArrayList<>(), String.class));
        } catch (Throwable ex) {
            ex.printStackTrace();
        }
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec05;

import java.util.ArrayList;
import java.util.List;

    public class WordList extends ArrayList<String> {
        public boolean add(String e) {
            return isBadWord(e) ? false : super.add(e);
        }
        
        public String get(int i) {
            return super.get(i).toLowerCase();
        }        
                
        public static boolean isBadWord(String s) {
            return List.of("sex", "drugs", "c++").contains(s.toLowerCase());
        }        
    }
//_______________________________________________________________________________________

package ch06.sec05;

import java.util.ArrayList;

public class WordListDemo {
    public static void main(String[] args) {
        WordList words = new WordList();
        ArrayList<String> strings = words; // Ok—conversion to superclass
        strings.add("Hello");
        strings.add("C++");
        System.out.println(words);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec06;

import java.util.ArrayList;
import java.util.function.IntFunction;

public class ArrayUtil {
    public static <T> T[] repeat(int n, T obj, IntFunction<T[]> constr) {
        T[] result = constr.apply(n); 
        for (int i = 0; i < n; i++) result[i] = obj;
        return result;
    }
    
    public static int[] repeat(int n, int obj, IntFunction<int[]> constr) {
        int[] result = constr.apply(n); 
        for (int i = 0; i < n; i++) result[i] = obj;
        return result;
    }
    
    public static <T> T[] repeat(int n, T obj, T[] array) {
        T[] result;
        if (array.length >= n)
            result = array;
        else {
            @SuppressWarnings("unchecked") T[] newArray
               = (T[]) java.lang.reflect.Array.newInstance(
                   array.getClass().getComponentType(),  n);
            result = newArray;
        }   
        for (int i = 0; i < n; i++) result[i] = obj;
        return result;
    }    
    
    @SafeVarargs public static <T> ArrayList<T> asList(T... elements) {
        ArrayList<T> result = new ArrayList<>();
        for (T e : elements) result.add(e);
        return result;
    }
}

//_______________________________________________________________________________________

package ch06.sec06;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.Callable;

public class Exceptions {
    @SuppressWarnings("unchecked")
    private static <T extends Throwable> void throwAs(Throwable e) throws T {
        throw (T) e; // 
    }
    
    public static <V> V doWork(Callable<V> c) {
        try {
            return c.call();
        } catch (Throwable ex) { 
            Exceptions.<RuntimeException>throwAs(ex);
            return null;
        }
    }
    
    public static String readAll(Path path) {
        return doWork(() -> Files.readString(path)); 
    }
    
    public static void main(String[] args) {
        String result = readAll(Paths.get("/tmp/quuqux"));
        System.out.println(result);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch06.sec07;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GenericReflectionDemo {
    public static void main(String[] args) throws ReflectiveOperationException {
        TypeVariable<Class<ArrayList>>[] vars = ArrayList.class.getTypeParameters();
        String name = vars[0].getName(); // "E"
        System.out.println(name);
        
        Method m = Collections.class.getMethod("sort", List.class);
        TypeVariable<Method>[] vars2 = m.getTypeParameters();
        name = vars2[0].getName(); // "T"
        System.out.println(name);

        Type[] bounds = vars2[0].getBounds();
        if (bounds[0] instanceof ParameterizedType) { // Comparable<? super T>
            ParameterizedType p = (ParameterizedType) bounds[0];
            Type[] typeArguments = p.getActualTypeArguments();
            if (typeArguments[0] instanceof WildcardType) { // ? super T
                WildcardType t = (WildcardType) typeArguments[0];
                Type[] upper = t.getUpperBounds(); // ? extends ... & ...
                Type[] lower = t.getLowerBounds(); // ? super ... & ...
                if (lower.length > 0) {        
                    String description = lower[0].getTypeName(); // "T"
                    System.out.println(description);
                }
            }
        }
    }
}
