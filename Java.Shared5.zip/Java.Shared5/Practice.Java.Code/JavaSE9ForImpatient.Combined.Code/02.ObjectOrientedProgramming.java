
//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch02.sec01;

import java.time.DayOfWeek;
import java.time.LocalDate;

public class Cal {
    public static void main(String[] args) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}

//_______________________________________________________________________________________

package ch02.sec01;

import java.util.ArrayList;

public class ReferenceDemo {
    public static void main(String[] args) {
        ArrayList<String> friends = new ArrayList<>();
            // friends is empty
        friends.add("Peter");
            // friends has size 1
        ArrayList<String> people = friends;
            // Now people and friends refer to the same object
        people.add("Paul");
        System.out.println(friends);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch02.sec02;

public class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

//_______________________________________________________________________________________

package ch02.sec02;

public class EmployeeDemo {
    public static void main(String[] args) {
        Employee fred = new Employee("Fred", 50000);
        fred.raiseSalary(10);
        System.out.println(fred.getName());
        System.out.println(fred.getSalary());
    }
}

//_______________________________________________________________________________________

package ch02.sec02;

import java.util.Random;

public class EvilManager {
    private Random generator;
    
    public EvilManager() {
        generator = new Random();
    }
    
    public void giveRandomRaise(Employee e) {
        double percentage = 10 * generator.nextDouble();
        e.raiseSalary(percentage);
    }
    
    public void increaseRandomly(double x) { // Won't work
        double amount = x * 10 * generator.nextDouble();
        x += amount;
    }
    
    public void replaceWithZombie(Employee e) {
        e = new Employee("", 0);
    }
}
//_______________________________________________________________________________________

package ch02.sec02;

public class CallByValueDemo {
    public static void main(String[] args) {
        EvilManager boss = new EvilManager();
        
        Employee fred = new Employee("Fred", 50000);
        System.out.println("Salary before: " + fred.getSalary());            
        boss.giveRandomRaise(fred);
        System.out.println("Salary after: " + fred.getSalary());

        double sales = 100000;
        System.out.println("Sales before: " + sales);
        boss.increaseRandomly(sales);
        System.out.println("Sales after: " + sales);
        
        System.out.println("Employee before: " + fred.getName());            
        boss.replaceWithZombie(fred);
        System.out.println("Employee after: " + fred.getName());            
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch02.sec03;

import java.util.Random;

public class Employee {
    private String name = "";
    private double salary;
    private final int id;
        
    { // An initialization block
        Random generator = new Random(); 
        id = 1 + generator.nextInt(1_000_000);
    }
    
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    
    public Employee(double salary) {
        // name already set to ""
        this.salary = salary;
    }        
    
    public Employee(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    public Employee() {
        this("", 0);
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }
}

//_______________________________________________________________________________________

package ch02.sec03;

public class EmployeeDemo {
    public static void main(String[] args) {
        Employee james = new Employee("James Bond", 500000);
            // calls Employee(String, double) constructor
        Employee anonymous = new Employee("", 40000);
            // calls Employee(double) constructor
        Employee unpaid = new Employee("Igor Intern");
        Employee e = new Employee();
            // no-arg constructor
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch02.sec04;

import java.time.LocalDate;
import java.util.ArrayList;

public class CreditCardForm {
    private static final ArrayList<Integer> expirationYear = new ArrayList<>();
    static {
        // Add the next twenty years to the array list
        int year = LocalDate.now().getYear();
        for (int i = year; i <= year + 20; i++) {
            expirationYear.add(i);
        }   
    }
    // ...
}

//_______________________________________________________________________________________

package ch02.sec04;

public class Employee {
    private static int lastId = 0;
    private int id;
    private String name;
    private double salary;
        
    public Employee() {
        lastId++;
        id = lastId;
    }
    
    public Employee(String name, double salary) {
        this();
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }
}

//_______________________________________________________________________________________

package ch02.sec04;

import java.util.Random;

public class RandomNumbers {
    private static Random generator = new Random();
    public static int nextInt(int low, int high) {
        return low + generator.nextInt(high - low + 1);
            // Ok to access the static generator variable
    }
}
//_______________________________________________________________________________________

package ch02.sec04;

import java.text.NumberFormat;

public class StaticMethodDemo {
    public static void main(String[] args) {
        int dieToss = RandomNumbers.nextInt(1, 6); 
        System.out.println(dieToss);
        
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
        NumberFormat percentFormatter = NumberFormat.getPercentInstance();
        double x = 0.1;
        System.out.println(currencyFormatter.format(x)); // Prints $0.10
        System.out.println(percentFormatter.format(x)); // Prints 10%
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch02.sec05;

import static java.lang.Math.*;

public class StaticImportDemo {
    public static void main(String[] args) {
        double x = 3;
        double y = 4;
        double hypothenuse = sqrt(pow(x, 2) + pow(y, 2)); // i.e., Math.sqrt, Math.pow
        System.out.println(hypothenuse);        
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch02.sec06;

import java.util.ArrayList;

public class Invoice {
    private static class Item { // Item is nested inside Invoice
        String description;
        int quantity;
        double unitPrice;

        double price() { return quantity * unitPrice; }
        public String toString() { 
            return quantity + " x " + description + " @ $" + unitPrice + " each";
        }
    }

    private ArrayList<Item> items = new ArrayList<>();
    
    public void addItem(String description, int quantity, double unitPrice) {
        Item newItem = new Item();
        newItem.description = description;
        newItem.quantity = quantity;
        newItem.unitPrice = unitPrice;
        items.add(newItem);
    }
    
    public void print() {
        double total = 0;
        for (Item item : items) {
            System.out.println(item);
            total += item.price();
        }
        System.out.println(total);
    }
}
//_______________________________________________________________________________________

package ch02.sec06;

public class InvoiceDemo {
    public static void main(String[] args) {
        Invoice invoice = new Invoice();
        invoice.addItem("Blackwell Toaster", 2, 24.95);
        invoice.addItem("ZapXpress Microwave Oven", 1, 49.95);
        invoice.print();
    }
}

//_______________________________________________________________________________________

package ch02.sec06;

import java.util.ArrayList;

public class Network {
    public class Member { // Member is an inner class of Network
        private String name;
        private ArrayList<Member> friends = new ArrayList<>();

        public Member(String name) {
            this.name = name;
        }

        public void deactivate() {
            members.remove(this);
        }

        public void addFriend(Member newFriend) {
            friends.add(newFriend);
        }

        public boolean belongsTo(Network n) {
            return Network.this == n;
        }
        
        public String toString() {
            StringBuilder result = new StringBuilder(name);
            result.append(" with friends ");
            for (Member friend : friends) {
                result.append(friend.name);
                result.append(", ");
            }
            return result.subSequence(0, result.length() - 2).toString();
        }
    }

    private ArrayList<Member> members = new ArrayList<>();

    public Member enroll(String name) {
        Member newMember = new Member(name);
        members.add(newMember);
        return newMember;
    }

    public String toString() {
        return members.toString();
    }
}
//_______________________________________________________________________________________

package ch02.sec06;

public class NetworkDemo {
    public static void main(String[] args) {
        Network myFace = new Network();
        Network tooter = new Network();
        Network.Member fred = myFace.enroll("Fred");
        Network.Member wilma = myFace.new Member("Wilma");
            // An object, but not enrolled
            // Make the constructor private to avoid this
        fred.addFriend(wilma);

        Network.Member barney = tooter.enroll("Barney");
        fred.addFriend(barney);
        System.out.println(myFace);
            // If it shouldn't be possible to add a friend
            // from another network, call belongsTo
        System.out.println(barney.belongsTo(myFace));
    }
}
