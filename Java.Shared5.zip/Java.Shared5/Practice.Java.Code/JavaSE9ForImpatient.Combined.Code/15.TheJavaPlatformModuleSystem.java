
//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.hello;

public class HelloWorld {
    public static void main(String[] args) {
       System.out.println("Hello, Modular World!");
    }
}

//_______________________________________________________________________________________

module ch15.sec03 {
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.hello;

import javax.swing.JOptionPane;

public class HelloWorld {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Hello, Modular World!");
    }
}

//_______________________________________________________________________________________

@SuppressWarnings("module")
module ch15.sec04 {
   requires java.desktop;
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.hello;

import com.horstmann.greet.Greeter;

public class HelloWorld {
    public static void main(String[] args) {
       Greeter greeter = Greeter.newInstance();
       System.out.println(greeter.greet("Modular World"));
    }
}

//_______________________________________________________________________________________

@SuppressWarnings("module")
module ch15.sec05 {
   requires com.horstmann.greet;
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.places;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Country {
   @XmlElement private String name;
   @XmlElement private double area;

   public Country() {}
   
   public Country(String name, double area) {
      this.name = name;
      this.area = area;
   }

   public String getName() {
      return name;
   }

   public double getArea() {
      return area;
   }
}

//_______________________________________________________________________________________

package com.horstmann.places;

import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class Demo {
   public static void main(String[] args) throws JAXBException {
      Country belgium = new Country("Belgium", 30510);
      JAXBContext context = JAXBContext.newInstance(Country.class);
      Marshaller m = context.createMarshaller();
      m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      m.marshal(belgium, System.out);
   }
}

//_______________________________________________________________________________________

@SuppressWarnings("module")
module ch15.sec06 {
   requires java.xml.bind;
   opens com.horstmann.places to java.xml.bind;
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.hello;

import com.horstmann.greetsvc.GreeterService;
import java.util.Locale;
import java.util.ServiceLoader;

public class HelloWorld {
    public static void main(String[] args) {
        ServiceLoader<GreeterService> greeterLoader
            = ServiceLoader.load(GreeterService.class);
        GreeterService chosenGreeter = null;
        for (GreeterService greeter : greeterLoader) {
            if (args.length > 0 &&
                  greeter.getLocale().getLanguage().equals(args[0]))
               chosenGreeter = greeter;
        }
        if (chosenGreeter == null)
           System.out.println("No suitable greeter. Try with arg de or fr");
        else
           System.out.println(chosenGreeter.greet("Modular World"));
    }
}

//_______________________________________________________________________________________

@SuppressWarnings("module")
module ch15.sec08 {
   requires com.horstmann.greetsvc;
   uses com.horstmann.greetsvc.GreeterService;
}

//_______________________________________________________________________________________

@SuppressWarnings("module")
module ch15.sec08 {
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.places;

import java.io.*;
import org.apache.commons.csv.*;

public class CSVDemo {
   public static void main(String[] args) throws IOException {
      Reader in = new FileReader("countries.csv");
      Iterable<CSVRecord> records = CSVFormat.EXCEL.withDelimiter(';').withHeader().parse(in);
      for (CSVRecord record : records) {
         String name = record.get("Name");
         double area = Double.parseDouble(record.get("Area"));
         System.out.println(name + " has area " + area);
      }
   }
}

//_______________________________________________________________________________________

@SuppressWarnings("module")
module ch15.sec09 {
   requires commons.csv;
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.places;

import java.io.*;
import org.apache.commons.csv.*;

public class CSVDemo {
   public static void main(String[] args) throws IOException {
      Reader in = new FileReader("countries.csv");
      Iterable<CSVRecord> records = CSVFormat.EXCEL.withDelimiter(';').withHeader().parse(in);
      for (CSVRecord record : records) {
         String name = record.get("Name");
         double area = Double.parseDouble(record.get("Area"));
         System.out.println(name + " has area " + area);
      }
   }
}

//_______________________________________________________________________________________

package com.horstmann.places;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Country {
   @XmlElement private String name;
   @XmlElement private double area;

   public Country() {}
   
   public Country(String name, double area) {
      this.name = name;
      this.area = area;
   }

   public String getName() {
      return name;
   }

   public double getArea() {
      return area;
   }
}

//_______________________________________________________________________________________

package com.horstmann.places;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

public class Demo {
   public static void main(String[] args) throws JAXBException {
      Country belgium = new Country("Belgium", 30510);
      JAXBContext context = JAXBContext.newInstance(Country.class);
      Marshaller m = context.createMarshaller();
      m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      m.marshal(belgium, System.out);
   }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.greet;

public interface Greeter
{
    static Greeter newInstance()
    {
        return new com.horstmann.greet.internal.GreeterImpl();
    }

    String greet(String subject);   
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.greet.internal;

import com.horstmann.greet.Greeter;

public class GreeterImpl implements Greeter
{
    public String greet(String subject)
    {
        return "Hello, " + subject + "!";
    }
}

//_______________________________________________________________________________________

module com.horstmann.greet {
   exports com.horstmann.greet;
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.greetsvc;

import java.util.Locale;

public interface GreeterService {
    String greet(String subject);
    Locale getLocale();
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package com.horstmann.greetsvc.internal;

import com.horstmann.greetsvc.GreeterService;
import java.util.Locale;

public class FrenchGreeter implements GreeterService {
    public String greet(String subject) { return "Bonjour " + subject; }
    public Locale getLocale() { return Locale.FRENCH; }
}

//_______________________________________________________________________________________

package com.horstmann.greetsvc.internal;

import com.horstmann.greetsvc.GreeterService;
import java.util.Locale;
import java.util.Map;

public class GermanGreeter implements GreeterService {
   private Map<String, String> dictionary;
   public GermanGreeter(Map<String, String> dictionary) {
      this.dictionary = dictionary;
   }
    public String greet(String subject) {
       return "Hallo, " + dictionary.getOrDefault(subject, subject) + "!";
    }
    public Locale getLocale() { return Locale.GERMAN; }
}

//_______________________________________________________________________________________

package com.horstmann.greetsvc.internal;

import com.horstmann.greetsvc.GreeterService;
import java.util.Map;
import java.util.HashMap;

public class GermanGreeterFactory {
   public static GreeterService provider() {
      Map<String, String> dictionary = new HashMap<>();
      dictionary.put("World", "Welt");
      dictionary.put("Modular World", "modulare Welt");
      return new GermanGreeter(dictionary);
   }
}

//_______________________________________________________________________________________

module com.horstmann.greetsvc {
    exports com.horstmann.greetsvc;
    provides com.horstmann.greetsvc.GreeterService
       with com.horstmann.greetsvc.internal.FrenchGreeter, com.horstmann.greetsvc.internal.GermanGreeterFactory;
}

//_______________________________________________________________________________________

Name;Population;Area
Afghanistan;29835392;250000
Albania;2994667;11100
Algeria;34994937;919590
Andorra;84825;181
Angola;13338541;481351
Antigua and Barbuda;87884;171
Argentina;41769726;1068296
Armenia;2967975;11506
Australia;21766711;2967893
Austria;8217280;32382
Azerbaijan;8372373;33436
Bahamas, The;313312;5382
Bahrain;1214705;257
Bangladesh;158570535;55598
Barbados;286705;166
Belarus;9577552;80154
Belgium;10431477;11787
Belize;321115;8867
Benin;9325032;43483
Bhutan;708427;18147
Bolivia;10118683;424162
Bosnia and Herzegovina;4622163;19741
Botswana;2065398;231803
Brazil;203429773;3286470
Brunei;401890;2228
Bulgaria;7093635;42822
Burkina Faso;16751455;105869
Burundi;10216190;10745
Cambodia;14701717;69900
Cameroon;19711291;183567
Canada;34030589;3855081
Cape Verde;516100;1557
Central African Republic;4950027;240534
Chad;10758945;495752
Chile;16888760;292258
China;1336718015;3705386
Colombia;44725543;439733
Comoros;794683;838
Congo, Democratic Republic of the;71712867;905563
Congo, Republic of the;4243929;132046
Costa Rica;4576562;19730
Cote d'Ivoire;21504162;124502
Croatia;4483804;21831
Cuba;11087330;42803
Cyprus;1120489;3571
Czech Republic;10190213;30450
Denmark;5529888;16639
Djibouti;757074;8880
Dominica;72969;291
Dominican Republic;9956648;18815
Ecuador;15007343;109483
Egypt;82079636;386660
El Salvador;6071774;8124
Equatorial Guinea;668225;10830
Eritrea;5939484;46842
Estonia;1282963;17462
Ethiopia;90873739;435184
Fiji;883125;7054
Finland;5259250;130558
France;65312249;211208
Gabon;1576665;103346
Gambia;1797860;4363
Georgia;4585874;26911
Germany;81471834;137846
Ghana;24791073;92456
Greece;10760136;50942
Grenada;108419;133
Guatemala;13824463;42042
Guinea;10601009;94925
Guinea-Bissau;1596677;13946
Guyana;744768;83000
Haiti;9719932;10714
Honduras;8143564;43278
Hungary;9976062;35919
Iceland;311058;39768
India;1189172906;1269338
Indonesia;245613043;741096
Iran;77891220;636293
Iraq;30399572;168753
Ireland;4670976;27135
Israel;7473052;8019
Italy;61016804;116305
Jamaica;2868380;4244
Japan;126475664;145882
Jordan;6508271;35637
Kazakhstan;15522373;1049150
Kenya;41070934;224961
Kiribati;100743;313
Korea, North;24457492;46540
Korea, South;48754657;38023
Kosovo;1825632;4211
Kuwait;2595628;6880
Kyrgyzstan;5587443;76641
Laos;6477211;91428
Latvia;2204708;24938
Lebanon;4143101;4015
Lesotho;1924886;11720
Liberia;3786764;43000
Libya;6597960;679358
Liechtenstein;35236;62
Lithuania;3535547;25174
Luxembourg;503302;998
Macedonia;2077328;9781
Madagascar;21926221;226656
Malawi;15879252;45745
Malaysia;28728607;127316
Maldives;394999;116
Mali;14159904;478764
Malta;408333;122
Marshall Islands;67182;4577
Mauritania;3281634;397953
Mauritius;1303717;788
Mexico;113724226;761602
Micronesia, Federated States of;106836;271
Moldova;4314377;13067
Monaco;30539;1
Mongolia;3133318;603905
Montenegro;661807;5415
Morocco;31968361;172413
Mozambique;22948858;309494
Myanmar (Burma);53999804;261969
Namibia;2147585;318694
Nauru;9322;8
Nepal;29391883;54363
Netherlands;16847007;16033
New Zealand;4290347;103737
Nicaragua;5666301;49998
Niger;16468886;489189
Nigeria;155215573;356667
Norway;4691849;125181
Oman;3027959;82031
Pakistan;187342721;310401
Palau;20956;177
Panama;3460462;30193
Papua New Guinea;6187591;178703
Paraguay;6459058;157046
Peru;29248943;496223
Philippines;101833938;115830
Poland;38441588;120728
Portugal;10760305;35672
Qatar;848016;4416
Romania;21904551;91669
Russia;138739892;6592735
Rwanda;11370425;10169
Saint Kitts and Nevis;50314;101
Saint Lucia;161557;238
Saint Vincent and the Grenadines;103869;150
Samoa;193161;1137
San Marino;31817;24
Sao Tome and Principe;179506;386
Saudi Arabia;26131703;756981
Senegal;12643799;75749
Serbia;7310555;29913
Seychelles;89188;176
Sierra Leone;5363669;27699
Singapore;4740737;267
Slovakia;5477038;18859
Slovenia;2000092;7827
Solomon Islands;571890;10985
Somalia;9925640;246199
South Africa;49004031;471008
South Sudan;8260490;400367
Spain;46754784;194896
Sri Lanka;21283913;25332
Sudan;45047502;728215
Suriname;491989;63039
Swaziland;1370424;6704
Sweden;9088728;173731
Switzerland;7639961;15942
Syria;22517750;71498
Taiwan;23071779;13892
Tajikistan;7627200;55251
Tanzania;42746620;364898
Thailand;66720153;198455
Timor-Leste;1177834;5641
Togo;6771993;21925
Tonga;105916;289
Trinidad and Tobago;1227505;1980
Tunisia;10629186;63170
Turkey;78785548;301382
Turkmenistan;4997503;188455
Tuvalu;10544;10
Uganda;34612250;91135
Ukraine;45134707;233089
United Arab Emirates;5148664;32000
United Kingdom;62698362;94525
United States;313232044;3718691
Uruguay;3308535;68039
Uzbekistan;28128600;172741
Vanuatu;224564;4710
Vatican City;832;0.17
Venezuela;27635743;352143
Vietnam;90549390;127243
Western Sahara;507160;102703
Yemen;24133492;203849
Zambia;13881336;290584
Zimbabwe;12084304;150803

//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________


//_______________________________________________________________________________________

