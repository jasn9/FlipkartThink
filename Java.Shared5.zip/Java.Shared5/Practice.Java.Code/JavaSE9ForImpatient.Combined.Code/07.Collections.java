
//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch07.sec02;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class IteratorDemo {
    public static void main(String[] args) {
        Collection<String> coll = new ArrayList<>();
        coll.add("Peter");
        coll.add("Paul");
        coll.add("Mary");
        Iterator<String> iter = coll.iterator();
        while (iter.hasNext()) {
            String element = iter.next();
            process(element);
        }
        
        iter = coll.iterator();
        while (iter.hasNext()) {
            String element = iter.next();
            if (element.startsWith("M"))
                iter.remove();
        } 
        
        coll.removeIf(e -> e.endsWith("r"));
        
        for (String element : coll) 
            process(element);
    }
    
    public static void process(String s) { System.out.println("Processing " + s); }
}

//_______________________________________________________________________________________

package ch07.sec02;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class ListIteratorDemo {
    public static void main(String[] args) {
        List<String> friends = new LinkedList<>();
        ListIterator<String> iter = friends.listIterator();
        iter.add("Fred"); // Fred |
        iter.add("Wilma"); // Fred Wilma |
        iter.previous(); // Fred | Wilma
        iter.set("Barney"); // Fred | Barney
        System.out.println(friends);
    }
}

//_______________________________________________________________________________________

package ch07.sec02;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class ConcurrentModificationDemo {
    public static void main(String[] args) {
        Collection<String> coll = new ArrayList<>();
        coll.add("Peter");
        coll.add("Paul");
        coll.add("Mary");
        System.out.println(coll);
        Iterator<String> iter1 = coll.iterator();
        Iterator<String> iter2 = coll.iterator();
        iter2.next();
        iter2.remove();
        System.out.println(coll);
        iter1.next();
        System.out.println(coll);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch07.sec03;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
    public static void main(String[] args) {
        Set<String> badWords = new HashSet<>();
        badWords.add("sex");
        badWords.add("drugs");
        badWords.add("c++");
        
        Scanner in = new Scanner(System.in);
        System.out.print("Please choose a user name: ");
        String username = in.next();        
        if (badWords.contains(username.toLowerCase()))
            System.out.println("Please choose a different user name");
        else
            System.out.println("Registered " + username + " since it wasn't one of " + badWords);
        
        TreeSet<String> countries = new TreeSet<>((u, v) ->
            u.equals(v) ? 0
            : u.equals("USA") ? -1
            : v.equals("USA") ? 1
            : u.compareTo(v));
        
        countries.add("Bahrain");
        countries.add("Australia");
        countries.add("USA");
        countries.add("Canada");
        System.out.println(countries);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch07.sec04;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {
    public static void main(String[] args) {
        Map<String, Integer> counts = new HashMap<>();
        counts.put("Alice", 1); // Adds the key/value pair to the map
        counts.put("Alice", 2); // Updates the value for the key
        
        int count = counts.get("Alice");
        System.out.println(count);
        count = counts.getOrDefault("Barney", 0);
        System.out.println(count);
        
        String word = "Fred";
        counts.merge(word, 1, Integer::sum);
        counts.merge(word, 1, Integer::sum);
        System.out.println(counts.get(word));

        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();
            process(key, value);
        }
        
        counts.forEach((k, v) -> process(k, v));
    }
    
    public static void process(String key, Integer value) {
        System.out.printf("Processing key %s and value %d\n", key, value);
    }
        
}

//_______________________________________________________________________________________

package ch07.sec04;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class LinkedHashMapDemo {
    public static void main(String[] args) {
        Map<String, Integer> weekdays = new HashMap<>();
        initialize(weekdays);
        System.out.println(weekdays);
        
        weekdays = new TreeMap<>();
        initialize(weekdays);
        System.out.println(weekdays);
        
        weekdays = new LinkedHashMap<>();
        initialize(weekdays);
        System.out.println(weekdays);
    }
    
    public static void initialize(Map<String, Integer> weekdays) {
        weekdays.put("Monday", 1);
        weekdays.put("Tuesday", 2);
        weekdays.put("Wednesday", 3);
        weekdays.put("Thursday", 4);
        weekdays.put("Friday", 5);
        weekdays.put("Saturday", 6);
        weekdays.put("Sunday", 7);
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch07.sec05;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

public class PropertiesDemo {
    public static void main(String[] args) throws IOException {
        Properties settings = new Properties();
        settings.put("width", "200");
        settings.put("title", "Hello, World!");
        Path path = Paths.get("demo.properties");
        try (OutputStream out = Files.newOutputStream(path)) {
            settings.store(out, "Program Properties");
        }
        
        settings = new Properties();
        try (InputStream in = Files.newInputStream(path)) {
            settings.load(in);
        }
        System.out.println(settings);
        
        String title = settings.getProperty("title", "New Document");
        String height = settings.getProperty("height", "100");
        System.out.println(title);
        System.out.println(height);
        System.out.println();
        System.out.println("System properties");
        Properties sysprops = System.getProperties();
        sysprops.forEach((k, v) -> System.out.printf("%s=%s\n", k, v));
    }
}

//_______________________________________________________________________________________

package ch07.sec05;

import java.util.BitSet;

public class BitsetDemo {
    public static void main(String[] args) {
        // This program demonstrates the Sieve of Erathostenes for finding primes
        int n = 100000;
        BitSet primes = new BitSet(n + 1);
        for (int i = 2; i <= n; i++)
           primes.set(i);
        for (int i = 2; i * i <= n; i++) {
           if (primes.get(i)) {
              for (int k = 2 * i; k <= n; k += i)
                 primes.clear(k);
           }
        }
        System.out.println(primes);
    }
}

//_______________________________________________________________________________________

package ch07.sec05;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Set;

public class EnumSetDemo {
    enum Weekday { MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY };
    public static void main(String[] args) {
        Set<Weekday> always = EnumSet.allOf(Weekday.class);
        Set<Weekday> never = EnumSet.noneOf(Weekday.class);
        Set<Weekday> workday = EnumSet.range(Weekday.MONDAY, Weekday.FRIDAY);
        Set<Weekday> mwf = EnumSet.of(Weekday.MONDAY, Weekday.WEDNESDAY, Weekday.FRIDAY);
        System.out.println(always);
        System.out.println(never);
        System.out.println(workday);
        System.out.println(mwf);
        
        EnumMap<Weekday, String> personInCharge = new EnumMap<>(Weekday.class);
        personInCharge.put(Weekday.MONDAY, "Fred");
        System.out.println(personInCharge);
    }
}

//_______________________________________________________________________________________

package ch07.sec05;

import java.util.ArrayDeque;
import java.util.Queue;

public class StackQueueDemo {
    public static void main(String[] args) {
        ArrayDeque<String> stack = new ArrayDeque<>();
        stack.push("Peter");
        stack.push("Paul");
        stack.push("Mary");
        while (!stack.isEmpty())
            System.out.println(stack.pop());
        
        System.out.println();
        
        Queue<String> queue = new ArrayDeque<>();
        queue.add("Peter");
        queue.add("Paul");
        queue.add("Mary");
        while (!queue.isEmpty())
            System.out.println(queue.remove());
        
    }
}

//_______________________________________________________________________________________

package ch07.sec05;

import java.util.PriorityQueue;

public class PriorityQueueDemo {
    public static void main(String[] args) {
        PriorityQueue<Job> jobs = new PriorityQueue<>();
        jobs.add(new Job(4, "Collect garbage"));
        jobs.add(new Job(9, "Match braces"));
        jobs.add(new Job(1, "Fix memory leak"));
        
        while (jobs.size() > 0) {
            Job job = jobs.remove(); // The most urgent jobs are removed first
            execute(job);
        } 
    }
    
    public static void execute(Job job) {
        System.out.println(job.getDescription());
    }
}

//_______________________________________________________________________________________

package ch07.sec05;

public class Job implements Comparable<Job> {
    private int priority;
    private String description;
    
    public Job(int priority, String description) {
        this.priority = priority;
        this.description = description;
    }

    public int compareTo(Job other) {
        return priority - other.priority;
    }
    
    public String getDescription() {
        return description;
    }
}

//_______________________________________________________________________________________


//_______________________________________________________________________________________

package ch07.sec06;

import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class RangeDemo {
    public static void main(String[] args) {
        List<String> sentence = List.of("A man, a plan, a cat, a ham, a yak, a yam, a hat, a canal, Panama!".split("[ ,]+"));
        List<String> nextFive = sentence.subList(5, 10);
        System.out.println(nextFive);
        
        TreeSet<String> words = new TreeSet<>(sentence);
        words.add("zebra");
        SortedSet<String> ysOnly = words.subSet("y", "z");
        System.out.println(ysOnly);
        
        SortedSet<String> nAndBeyond = words.tailSet("p");
        System.out.println(nAndBeyond);
    }
}
