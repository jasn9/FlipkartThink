// ../src/09realworld
// ../src/09realworld/favor_logging_over_console_output
// ../src/09realworld/favor_logging_over_console_output/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package realworld.favor_logging_over_console_output.problem;

import java.util.Arrays;
import java.util.List;

import general.favor_foreach_over_for.Commander;
import general.favor_foreach_over_for.Status;

class Test {

}

class LaunchChecklist {

    List<String> checks = Arrays.asList("Cabin Pressure",
                                        "Communication",
                                        "Engine");

    Status prepareAscend(Commander commander) {
        System.out.println("Prepare ascend");
        for (String check : checks) {
            if (commander.isFailing(check)) {
                System.out.println(check + " ... FAILURE");
                System.err.println("Abort take off");
                return Status.ABORT_TAKE_OFF;
            }
            System.out.println(check + " ... OK");
        }
        System.out.println("Read for take off");
        return Status.READY_FOR_TAKE_OFF;
    }
}

//_______________________________________________________________________

// ../src/09realworld/favor_logging_over_console_output/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package realworld.favor_logging_over_console_output.solution;

import java.util.Arrays;
import java.util.List;

import general.favor_foreach_over_for.Commander;
import general.favor_foreach_over_for.Status;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

class Test {

}

class LaunchChecklist {

    private static final Logger LOGGER =
            LogManager.getLogger(LaunchChecklist.class);

    List<String> checks = Arrays.asList("Cabin Pressure",
                                        "Communication",
                                        "Engine");

    Status prepareAscend(Commander commander) {
        LOGGER.info("{}: Prepare ascend", commander);
        LOGGER.debug("{} Checks: {}", checks.size(), checks);
        for (String check : checks) {
            if (commander.isFailing(check)) {
                LOGGER.warn("{}: {} ... FAILURE", commander, check);
                LOGGER.error("{}: Abort take off!", commander);
                return Status.ABORT_TAKE_OFF;
            }
            LOGGER.info("{}: {} ... OK", commander, check);
        }
        LOGGER.info("{}: Read for take off!", commander);
        return Status.READY_FOR_TAKE_OFF;
    }
}

//_______________________________________________________________________

// ../src/09realworld/speed_up_your_program
// ../src/09realworld/speed_up_your_program/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package realworld.speed_up_your_program.problem;

import java.util.List;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();

    boolean isContaminated();
}

class Inventory {

    List<Supply> supplies;

    long countDifferentKinds() {
        return supplies.stream()
                       .sequential() // this can be omitted
                       .filter(Supply::isUncontaminated)
                       .map(Supply::getName)
                       .distinct()
                       .count();
    }
}

//_______________________________________________________________________

// ../src/09realworld/speed_up_your_program/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package realworld.speed_up_your_program.solution;

import java.util.List;

class Test {

}

interface Supply {

    String getName();

    boolean isContaminated();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies;

    long countDifferentKinds() {
        return supplies.stream()
                       .parallel()
                       .filter(Supply::isUncontaminated)
                       .map(Supply::getName)
                       .distinct()
                       .count();
    }
}

//_______________________________________________________________________

// ../src/09realworld/validate_your_data
// ../src/09realworld/validate_your_data/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package realworld.validate_your_data.problem;

class Test {

}

class NameTag {

    final String name;

    NameTag(String fullName) {
        this.name = parse(fullName).toUpperCase();
    }

    String parse(String fullName) {
        String[] components = fullName.split("[,| ]");
        if (components == null || components.length < 2) {
            return fullName;
        }
        if (fullName.contains(",")) {
            return components[0];
        } else {
            return components[components.length - 1];
        }
    }
}

class Usage {

     static void main(String[] args) {
        System.out.println(new NameTag("Neil Armstrong").name);
        System.out.println(new NameTag("Neil Alden Armstrong").name);
        System.out.println(new NameTag("Armstrong, Neil").name);
        System.out.println(new NameTag("Edwin Eugene Aldrin, Jr.").name);
        System.out.println(new NameTag("William \"Bill\" H. Gates III").name);
        System.out.println(new NameTag("刘伯明").name);
    }
}

//_______________________________________________________________________

// ../src/09realworld/validate_your_data/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package realworld.validate_your_data.solution;

import java.util.Objects;

class Test {

}

class NameTag {

    final String name;

    NameTag(String name) {
        Objects.requireNonNull(name);
        this.name = name;
    }
}

class Usage {

     static void main(String[] args) {
        System.out.println(new NameTag("ARMSTRONG").name);
        System.out.println(new NameTag("ARMSTRONG").name);
        System.out.println(new NameTag("ALDRIN").name);
        System.out.println(new NameTag("ARMSTRONG").name);
        System.out.println(new NameTag("GATES").name);
        System.out.println(new NameTag("刘").name);
    }
}

//_______________________________________________________________________

