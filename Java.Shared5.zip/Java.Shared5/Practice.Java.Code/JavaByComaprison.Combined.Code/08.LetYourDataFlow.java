// ../src/08lambdas
// ../src/08lambdas/favor_lambdas_over_anonymous_classes
// ../src/08lambdas/favor_lambdas_over_anonymous_classes/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_lambdas_over_anonymous_classes.problem;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

class Test {

}

interface InterCom {

    void broadcast(String message);
}

class Calculator {

    Map<Double, Double> values = new HashMap<>();

    Double square(Double x) {
        Function<Double, Double> squareFunction =
                new Function<Double, Double>() {
                    @Override
                    public Double apply(Double value) {
                        return value * value;
                    }
                };
        return values.computeIfAbsent(x, squareFunction);
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_lambdas_over_anonymous_classes/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_lambdas_over_anonymous_classes.solution;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

class Test {

}

class Calculator {

    Map<Double, Double> values = new HashMap<>();

    Double square(Double value) {
        Function<Double, Double> squareFunction = factor -> factor * factor;
        return values.computeIfAbsent(value, squareFunction);
    }
}

class Calculator2 {

    Map<Double, Double> values;

    Double square(Double value) {
        /*
        // one-liner
        Function<Double, Double> squareFunction = factor -> factor * factor;
        //  multi-liner
        Function<Double, Double> squareFunction = factor -> {
            return factor * factor;
        };
        */
        return 1.0;
    }
}

/*

*/

class Calculator3 {

    Map<Double, Double> values;

    Double square(Double value) {
        /*
        // without type definition and braces
        Function<Double, Double> squareFunction = factor -> factor * factor;
        //  with type definition and braces
        Function<Double, Double> squareFunction = (Double factor) -> factor * factor;
        */
        return 1.0;
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_functional_over_imperative_style
// ../src/08lambdas/favor_functional_over_imperative_style/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_functional_over_imperative_style.problem;

import java.util.ArrayList;
import java.util.List;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        List<String> names = new ArrayList<>();
        for (Supply supply : supplies) {
            if (supply.isUncontaminated()) {
                String name = supply.getName();
                if (!names.contains(name)) {
                    names.add(name);
                }
            }
        }
        return names.size();
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_functional_over_imperative_style/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_functional_over_imperative_style.solution;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        return supplies.stream()
                       .filter(supply -> supply.isUncontaminated())
                       .map(supply -> supply.getName())
                       .distinct()
                       .count();
    }
}

class Whatever {
    void main() {
        Predicate<Supply> uncontaminated = supply -> supply.isUncontaminated();
        Function<Supply, String> supplyToName = supply -> supply.getName();
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_method_references_over_lambdas
// ../src/08lambdas/favor_method_references_over_lambdas/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_method_references_over_lambdas.problem;

import java.util.ArrayList;
import java.util.List;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();

    boolean isContaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        return supplies.stream()
                       .filter(supply -> !supply.isContaminated())
                       .map(supply -> supply.getName())
                       .distinct()
                       .count();
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_method_references_over_lambdas/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_method_references_over_lambdas.solution;

import java.util.ArrayList;
import java.util.List;

class Test {

}

interface Supply {

    String getName();

    boolean isContaminated();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        return supplies.stream()
                       .filter(Supply::isUncontaminated)
                       .map(Supply::getName)
                       .distinct()
                       .count();
    }
}

//_______________________________________________________________________

// ../src/08lambdas/avoid_side_effects
// ../src/08lambdas/avoid_side_effects/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.avoid_side_effects.problem;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        List<String> names = new ArrayList<>();

        Consumer<String> addToNames = name -> names.add(name);

        supplies.stream()
                .filter(Supply::isUncontaminated)
                .map(Supply::getName)
                .distinct()
                .forEach(addToNames);
        return names.size();
    }
}

//_______________________________________________________________________

// ../src/08lambdas/avoid_side_effects/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.avoid_side_effects.solution;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        List<String> names = supplies.stream()
                                     .filter(Supply::isUncontaminated)
                                     .map(Supply::getName)
                                     .distinct()
                                     .collect(Collectors.toList());
        return names.size();
    }
}

class Inventory2 {

    List<Supply> supplies = new ArrayList<>();

    long countDifferentKinds() {
        return supplies.stream()
                       .filter(Supply::isUncontaminated)
                       .map(Supply::getName)
                       .distinct()
                       .count();
    }
}

//_______________________________________________________________________

// ../src/08lambdas/use_collect_for_terminating_complex_streams
// ../src/08lambdas/use_collect_for_terminating_complex_streams/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.use_collect_for_terminating_complex_streams.problem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    Map<String, Long> countDifferentKinds() {
        Map<String, Long> nameToCount = new HashMap<>();

        Consumer<String> addToNames = name -> {
            if (!nameToCount.containsKey(name)) {
                nameToCount.put(name, 0L);
            }
            nameToCount.put(name, nameToCount.get(name) + 1);
        };

        supplies.stream()
                .filter(Supply::isUncontaminated)
                .map(Supply::getName)
                .forEach(addToNames);
        return nameToCount;
    }
}

//_______________________________________________________________________

// ../src/08lambdas/use_collect_for_terminating_complex_streams/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.use_collect_for_terminating_complex_streams.solution;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Test {

}

interface Supply {

    String getName();

    boolean isUncontaminated();
}

class Inventory {

    List<Supply> supplies = new ArrayList<>();

    Map<String, Long> countDifferentKinds() {
        return supplies.stream()
                       .filter(Supply::isUncontaminated)
                       .collect(Collectors.groupingBy(Supply::getName,
                               Collectors.counting())
                       );
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_optional_over_null
// ../src/08lambdas/favor_optional_over_null/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_optional_over_null.problem;

class Connection {

    void send(String message) {

    }
}

class Communicator {

    Connection connectionToEarth;

    void establishConnection() {
        // used to set connectionToEarth, but may be unreliable
    }

    Connection getConnectionToEarth() {
        return connectionToEarth;
    }
}

class Usage {
    static void main() {
        Communicator communicator = new Communicator();
        communicator.getConnectionToEarth()
                    .send("Houston, we got a problem!");
    }
}

//_______________________________________________________________________

// ../src/08lambdas/favor_optional_over_null/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.favor_optional_over_null.solution;

import java.util.Optional;

class Connection {

    void send(String message) {

    }
}

class Communicator {

    Connection connectionToEarth;

    void establishConnection() {
        // used to set connectionToEarth, but may be unreliable
    }

    Optional<Connection> getConnectionToEarth() {
        return Optional.ofNullable(connectionToEarth);
    }
}

class Usage {

    static void main() {
        Communicator communicator = new Communicator();

        Connection connection = communicator.getConnectionToEarth()
                                            .orElse(null);
        connection.send("Houston, we got a problem!");
    }

    static void main2() {
        Communicator communicationSystem = new Communicator();

        communicationSystem.getConnectionToEarth()
                            .ifPresent(connection ->
                                connection.send("Houston, we got a problem!")
                            );
    }
}

//_______________________________________________________________________

// ../src/08lambdas/avoid_optional_fields_or_parameters
// ../src/08lambdas/avoid_optional_fields_or_parameters/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.avoid_optional_fields_or_parameters.problem;

import java.util.Optional;

class Connection {

    void send(String message) {

    }
}

class Communicator {

    Optional<Connection> connectionToEarth;
    
    void setConnectionToEarth(Optional<Connection> connectionToEarth) {
        this.connectionToEarth = connectionToEarth;
    }
    Optional<Connection> getConnectionToEarth() {
        return connectionToEarth;
    }
}

//_______________________________________________________________________

// ../src/08lambdas/avoid_optional_fields_or_parameters/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.avoid_optional_fields_or_parameters.solution;

import java.util.Objects;
import java.util.Optional;

class Connection {

    void send(String message) {

    }
}

class Communicator {

    Connection connectionToEarth;

    void setConnectionToEarth(Connection connectionToEarth) {
        this.connectionToEarth = Objects.requireNonNull(connectionToEarth);
    }
    Optional<Connection> getConnectionToEarth() {
        return Optional.ofNullable(connectionToEarth);
    }

    void reset() {
        connectionToEarth = null;
    }
}

//_______________________________________________________________________

// ../src/08lambdas/use_optionals_as_streams
// ../src/08lambdas/use_optionals_as_streams/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.use_optionals_as_streams.problem;

import java.util.Optional;

interface Connection {

    void send(String message);

    boolean isFree();
}

interface Storage {

    String getBackup();
}

class Communicator {

    private Connection connectionToEarth;

    Optional<Connection> getConnectionToEarth() {
        return Optional.ofNullable(connectionToEarth);
    }
}

class BackupJob {

    Communicator communicator;
    Storage storage;

    void backupToEarth() {
        Optional<Connection> connectionOptional =
                communicator.getConnectionToEarth();
        if (!connectionOptional.isPresent()) {
            throw new IllegalStateException();
        }

        Connection connection = connectionOptional.get();
        if (!connection.isFree()) {
            throw new IllegalStateException();
        }

        connection.send(storage.getBackup());
    }
}


//_______________________________________________________________________

// ../src/08lambdas/use_optionals_as_streams/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.use_optionals_as_streams.solution;

import java.util.Optional;


interface Connection {

    void send(String message);

    boolean isFree();
}

interface Logbook {

    void log(String message);
}

interface Storage {

    String getBackup();
}

class Communicator {

    private Connection connectionToEarth;

    Optional<Connection> getConnectionToEarth() {
        return Optional.ofNullable(connectionToEarth);
    }
}

class BackupJob {

    Communicator communicator;
    Storage storage;

    void backupToEarth() {
        Connection connection = communicator.getConnectionToEarth()
                .filter(Connection::isFree)
                .orElseThrow(IllegalStateException::new);
        connection.send(storage.getBackup());
    }
}

class Usage {

    static void main() {
        Communicator communicator = null;
        String state = communicator.getConnectionToEarth()
                                    .map(Connection::isFree)
                                    .map(isFree -> isFree ? "free" : "busy")
                                    .orElse("absent");
    }
}


//_______________________________________________________________________

// ../src/08lambdas/avoid_exceptions_in_streams
// ../src/08lambdas/avoid_exceptions_in_streams/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.avoid_exceptions_in_streams.problem;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

class Test {

}

class LogBook {

    LogBook(Path path) throws IOException {
        Files.readAllLines(path);
    }

    static boolean isLogbook(Path path) {
        return false;
    }
}

class LogBooks {

    static List<LogBook> getAll() throws IOException {
        return Files.walk(Paths.get("/var/log"))
                    .filter(Files::isRegularFile)
                    .filter(LogBook::isLogbook)
                    .map(path -> {
                        try {
                            return new LogBook(path);
                        } catch (IOException e) {
                            throw new UncheckedIOException(e);
                        }
                    })
                    .collect(Collectors.toList());
    }
}

//_______________________________________________________________________

// ../src/08lambdas/avoid_exceptions_in_streams/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.avoid_exceptions_in_streams.solution;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Test {

}

class LogBook {

    LogBook(Path path) throws IOException {
        Files.readAllLines(path);
    }

    static boolean isLogbook(Path path) {
        return false;
    }
}

class LogBooks {

    static List<LogBook> getAll() throws IOException {
        try (Stream<Path> stream = Files.walk(Paths.get("/var/log"))) {
            return stream.filter(Files::isRegularFile)
                         .filter(LogBook::isLogbook)
                         .flatMap(path -> {
                             try {
                                 return Stream.of(new LogBook(path));
                             } catch (IOException e) {
                                 return Stream.empty();
                             }
                         })
                         .collect(Collectors.toList());
        }
    }
}

class LogBooks2 {

    private static Path STORAGE = Paths.get("/var/log");

    static List<LogBook> getAll() throws IOException {
        try (Stream<Path> stream = Files.walk(STORAGE)) {

            return stream.filter(Files::isRegularFile)
                         .filter(LogBook::isLogbook)
                         .map(path -> {
                             try {
                                 return new LogBook(path);
                             } catch (IOException e) {
                                 return null;
                             }
                         })
                         .filter(Objects::nonNull)
                         .collect(Collectors.toList());
        }
    }
}

//_______________________________________________________________________

// ../src/08lambdas/handle_exceptions_in_streams
// ../src/08lambdas/handle_exceptions_in_streams/problem
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.handle_exceptions_in_streams.problem;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

class Test {

}

class LogBook {

    LogBook(Path path) throws IOException {
        Files.readAllLines(path);
    }

    static boolean isLogbook(Path path) {
        return false;
    }
}

class LogBooks {

    private static Path STORAGE = Paths.get("/var/log");

    static List<LogBook> getAll() throws IOException {
        return Files.walk(STORAGE)
                    .filter(Files::isRegularFile)
                    .filter(LogBook::isLogbook)
                    .map(path -> {
                        try {
                            return new LogBook(path);
                        } catch (IOException e) {
                            throw new UncheckedIOException(e);
                        }
                    })
                    .collect(Collectors.toList());
    }
}

//_______________________________________________________________________

// ../src/08lambdas/handle_exceptions_in_streams/solution
/***
 * Excerpted from "Java By Comparison",
 * published by The Pragmatic Bookshelf.
 * Copyrights apply to this code. It may not be used to create training material,
 * courses, books, articles, and the like. Contact us if you are in doubt.
 * We make no guarantees that this code is fit for any purpose.
 * Visit http://www.pragmaticprogrammer.com/titles/javacomp for more book information.
***/
package lambdas.handle_exceptions_in_streams.solution;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Test {

}

class LogBook {

    LogBook(Path path) throws IOException {
        Files.readAllLines(path);
    }

    static boolean isLogbook(Path path) {
        return false;
    }
}

class LogBooks {

    static Path STORAGE = Paths.get("/var/log");

    static List<LogBook> getAll() throws IOException {
        try (Stream<Path> stream = Files.walk(STORAGE)) {
            return stream.filter(Files::isRegularFile)
                         .filter(LogBook::isLogbook)
                         .flatMap(path -> {
                             try {
                                 return Stream.of(new LogBook(path));
                             } catch (IOException e) {
                                 return Stream.empty();
                             }
                         })
                         .collect(Collectors.toList());
        }
    }
}

class LogBooks2 {

    static Path STORAGE = Paths.get("/var/log");

    static List<LogBook> getAll() throws IOException {
        try (Stream<Path> stream = Files.walk(STORAGE)) {

            return stream.filter(Files::isRegularFile)
                         .filter(LogBook::isLogbook)
                         .map(path -> {
                             try {
                                 return new LogBook(path);
                             } catch (IOException e) {
                                 return null;
                             }
                         })
                         .filter(Objects::nonNull)
                         .collect(Collectors.toList());
        }
    }
}

//_______________________________________________________________________

