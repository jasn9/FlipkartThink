package ch03.sec01;

public interface IntSequence {
    boolean hasNext();
    int next();
}